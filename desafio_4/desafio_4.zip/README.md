
'''
automacao_vr_va/
|
├───dados/
│   └─── (Aqui você pode colocar as 5 planilhas de entrada)
|
├───ferramentas/
|   ├─── __init__.py
|   └─── ferramentas_planilha.py
|
├─── main.py
└─── requirements.txt

'''